package com.maxleveldetox.reels

import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * ReelsDetector (v2.0 Phase B1) — per-app, signature-based short-form
 * surface detection, ported from the reference app's proven strategies
 * (see apk-analysis/report-modes.md §3) and adapted to our privacy rules:
 *
 *   PRIVACY: node text / content-desc / view-ids are matched IN MEMORY and
 *   discarded. Nothing is persisted beyond (package, timestamp) by the
 *   caller's violation logging. No URL or caption text is ever stored.
 *
 * PER-APP STRATEGIES (each returns the detection *surface* so the
 * escalation ladder can treat a confirmed feed differently from a nav
 * hint):
 *
 *   YOUTUBE   view-id `reel_watch_fragment_root` (+ pivot_bar check: if the
 *             bottom bar is not visible the user is immersed -> BACK is the
 *             correct exit; otherwise HOME).
 *   TIKTOK    package gate = instant-home (the entire app IS the feed).
 *   FACEBOOK  "Reel details" text pre-check + bounded BFS (≤500 nodes)
 *             matching content descriptions; decision requires
 *             reel-details AND navigation AND (reels || fullscreen).
 *             Debounced by caller via scan-delay + block-debounce.
 *   FB LITE   view-id `video_view`.
 *   INSTAGRAM view-ids `root_clips_layout` (full) / `clips_viewer_video_container`
 *             (lite) / `reel_recycler` (shared).
 *   CHROME    `url_bar` text match against known shorts URL shapes.
 *
 * All strategies share a ≥500ms global debounce enforced by the caller
 * (DetoxAccessibilityService) plus per-app scan delays so content can
 * register before the yank (fewer false positives on feed previews).
 */
class ReelsDetector {

    enum class Surface {
        /** Confirmed immersive reels/shorts feed — full escalation applies. */
        FEED,
        /** Reels-adjacent navigation surface (tab, profile link) — counts,
         *  but the caller may treat it as a softer signal. */
        NAV,
        /** Browser URL pointing at a shorts feed. */
        URL,
    }

    data class Detection(val surface: Surface, val strategy: String)

    // (v2.5.5 audit fix M-11, option B: the caption-keyword allowlist that
    //  used to live here was never populated — no bridge method, no settings
    //  store, no UI. The dead field + isWhitelisted() check were removed so
    //  the detector's behavior matches the shipped product surface. If a
    //  keyword escape hatch is wanted later it needs the full stack:
    //  settings UI → StateRepository persistence → bridge → detector.)

    // -----------------------------------------------------------------
    // Entry point
    // -----------------------------------------------------------------

    fun detect(
        pkg: String,
        event: AccessibilityEvent,
        rootNode: AccessibilityNodeInfo?,
    ): Detection? {
        return when (pkg) {
            PKG_YOUTUBE -> detectYouTube(rootNode)
            PKG_TIKTOK, PKG_TIKTOK_REGIONAL -> detectTikTok()
            PKG_FACEBOOK -> detectFacebook(event, rootNode)
            PKG_FACEBOOK_LITE -> detectFacebookLite(rootNode)
            PKG_INSTAGRAM, PKG_INSTAGRAM_LITE -> detectInstagram(rootNode)
            PKG_CHROME, PKG_CHROME_BETA -> detectChrome(rootNode)
            else -> null
        }
    }

    // -----------------------------------------------------------------
    // YouTube — reel_watch_fragment_root + pivot_bar visibility
    // -----------------------------------------------------------------

    private fun detectYouTube(root: AccessibilityNodeInfo?): Detection? {
        val reelsRoot = findByViewId(root, "$PKG_YOUTUBE:id/reel_watch_fragment_root")
            ?: return null
        // The pivot_bar (bottom nav) tells us whether the user is immersed.
        // Either way this is a confirmed shorts feed.
        val pivotVisible = findByViewId(root, "$PKG_YOUTUBE:id/pivot_bar") != null
        return Detection(
            surface = Surface.FEED,
            strategy = if (pivotVisible) "yt_shorts_pivot" else "yt_shorts_immersed",
        )
    }

    // -----------------------------------------------------------------
    // TikTok — the whole app is the feed; package presence is enough.
    // -----------------------------------------------------------------

    private fun detectTikTok(): Detection =
        Detection(Surface.FEED, "tiktok_instant_home")

    // -----------------------------------------------------------------
    // Facebook — text pre-check + bounded BFS over content descriptions.
    // -----------------------------------------------------------------

    private fun detectFacebook(event: AccessibilityEvent, root: AccessibilityNodeInfo?): Detection? {
        // Cheap pre-check on event text first (avoids the BFS entirely for
        // the common case where the event carries the "Reel details" label).
        val eventText = event.text?.joinToString(separator = " ") { it?.toString() ?: "" } ?: ""
        if (eventText.contains("Reel details") || eventText.contains("Reels tab details")) {
            return Detection(Surface.FEED, "fb_reel_details_text")
        }

        if (root == null) return null

        val flags = HashSet<String>()
        bfsScan(root, MAX_BFS_NODES) { node ->
            val desc = node.contentDescription?.toString() ?: return@bfsScan false
            when {
                desc.contains("Reel details") || desc.contains("Reels tab details") ->
                    flags.add(FB_REEL_DETAILS)
                desc.contains("Navigate to your Reels profile") -> flags.add(FB_NAV)
                desc == "Reels" || desc.endsWith("Reels") -> flags.add(FB_REELS)
                desc.contains("Fullscreen") -> flags.add(FB_FULLSCREEN)
            }
            flags.size == 4 // early exit once everything is seen
        }

        val hasReelDetails = FB_REEL_DETAILS in flags
        val hasNav = FB_NAV in flags
        val hasReelsOrFullscreen = FB_REELS in flags || FB_FULLSCREEN in flags
        return if (hasReelDetails && hasNav && hasReelsOrFullscreen) {
            Detection(Surface.FEED, "fb_bfs_confirmed")
        } else if (hasReelDetails) {
            Detection(Surface.NAV, "fb_reel_details_partial")
        } else {
            null
        }
    }

    // -----------------------------------------------------------------
    // Facebook Lite — video_view id.
    // -----------------------------------------------------------------

    private fun detectFacebookLite(root: AccessibilityNodeInfo?): Detection? {
        val node = findByViewId(root, "$PKG_FACEBOOK_LITE:id/video_view") ?: return null
        // v2.5 r9.1: `video_view` also backs ordinary INLINE feed videos, so
        // the id alone would kick the user out of the normal news feed. A
        // reels/shorts surface is immersive: the video fills most of the
        // screen height. Inline players are far shorter.
        if (!isImmersive(node, root)) return null
        return Detection(Surface.FEED, "fb_lite_video_view")
    }

    /**
     * True when [node] covers at least half of the window height. If the
     * geometry cannot be read we keep the previous behaviour (treat as
     * immersive) rather than silently disabling detection.
     */
    private fun isImmersive(node: AccessibilityNodeInfo, root: AccessibilityNodeInfo?): Boolean {
        if (root == null) return true
        return try {
            val nodeBounds = android.graphics.Rect()
            val rootBounds = android.graphics.Rect()
            node.getBoundsInScreen(nodeBounds)
            root.getBoundsInScreen(rootBounds)
            val rootHeight = rootBounds.height()
            if (rootHeight <= 0) true else nodeBounds.height() * 2 >= rootHeight
        } catch (_: Exception) {
            true
        }
    }

    // -----------------------------------------------------------------
    // Instagram — clips layouts (full + lite + shared reel_recycler).
    // -----------------------------------------------------------------

    private fun detectInstagram(root: AccessibilityNodeInfo?): Detection? {
        if (findByViewId(root, "$PKG_INSTAGRAM:id/root_clips_layout") != null) {
            return Detection(Surface.FEED, "ig_root_clips")
        }
        if (findByViewId(root, "$PKG_INSTAGRAM_LITE:id/clips_viewer_video_container") != null) {
            return Detection(Surface.FEED, "ig_lite_clips_viewer")
        }
        if (findByViewId(root, "reel_recycler") != null) {
            return Detection(Surface.FEED, "ig_reel_recycler")
        }
        return null
    }

    // -----------------------------------------------------------------
    // Chrome — url_bar text match (URL itself is read in memory only).
    // -----------------------------------------------------------------

    private fun detectChrome(root: AccessibilityNodeInfo?): Detection? {
        val urlNode = findByViewId(root, "$PKG_CHROME:id/url_bar") ?: return null
        val url = urlNode.text?.toString()?.lowercase() ?: return null
        val isShortsUrl = SHORTS_URL_SHAPES.any { shape -> url.contains(shape) }
        return if (isShortsUrl) Detection(Surface.URL, "chrome_url") else null
    }

    // -----------------------------------------------------------------
    // Shared traversal helpers (bounded — TRD §78)
    // -----------------------------------------------------------------

    private fun findByViewId(root: AccessibilityNodeInfo?, viewId: String): AccessibilityNodeInfo? {
        if (root == null) return null
        val direct = try {
            root.findAccessibilityNodeInfosByViewId(viewId)
        } catch (_: Exception) {
            null
        }
        if (!direct.isNullOrEmpty()) return direct[0]
        // Partial-id fallback for OEM/version drift (e.g. no package prefix).
        val shortId = viewId.substringAfterLast(':')
        var found: AccessibilityNodeInfo? = null
        bfsScan(root, MAX_BFS_NODES) { node ->
            val id = node.viewIdResourceName ?: return@bfsScan false
            if (id.substringAfterLast(':') == shortId) {
                found = node
                true
            } else false
        }
        return found
    }

    /** Iterative breadth-first scan with a hard node cap. */
    private inline fun bfsScan(
        root: AccessibilityNodeInfo,
        maxNodes: Int,
        visit: (AccessibilityNodeInfo) -> Boolean,
    ) {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < maxNodes) {
            val node = queue.removeFirst()
            visited++
            if (visit(node)) return
            val children = node.childCount
            val limit = minOf(children, MAX_CHILDREN_PER_NODE)
            for (i in 0 until limit) {
                try {
                    node.getChild(i)?.let { queue.add(it) }
                } catch (_: Exception) {
                    // stale node mid-traversal — skip
                }
            }
        }
    }

    // (isWhitelisted() removed with M-11 — see note above the Detection class.)

    companion object {
        private const val PKG_YOUTUBE = "com.google.android.youtube"
        private const val PKG_TIKTOK = "com.zhiliaoapp.musically"
        private const val PKG_TIKTOK_REGIONAL = "com.ss.android.ugc.trill"
        private const val PKG_FACEBOOK = "com.facebook.katana"
        private const val PKG_FACEBOOK_LITE = "com.facebook.lite"
        private const val PKG_INSTAGRAM = "com.instagram.android"
        private const val PKG_INSTAGRAM_LITE = "com.instagram.lite"
        private const val PKG_CHROME = "com.android.chrome"
        private const val PKG_CHROME_BETA = "com.chrome.beta"

        private const val FB_REEL_DETAILS = "reel_details"
        private const val FB_NAV = "nav"
        private const val FB_REELS = "reels"
        private const val FB_FULLSCREEN = "fullscreen"

        private const val MAX_BFS_NODES = 500
        private const val MAX_CHILDREN_PER_NODE = 40

        /** URL shapes read from the Chrome url_bar (lowercased match). */
        private val SHORTS_URL_SHAPES = listOf(
            "youtube.com/shorts",
            "m.youtube.com/shorts",
            "facebook.com/reel/",
            "facebook.com/reels/",
            "instagram.com/reel/",
            "instagram.com/reels/",
        )

        /** Packages this detector has strategies for. */
        val SUPPORTED_PACKAGES = setOf(
            PKG_YOUTUBE, PKG_TIKTOK, PKG_TIKTOK_REGIONAL, PKG_FACEBOOK,
            PKG_FACEBOOK_LITE, PKG_INSTAGRAM, PKG_INSTAGRAM_LITE,
            PKG_CHROME, PKG_CHROME_BETA,
        )
    }
}
