import 'dart:convert';
import 'dart:math';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../core/constants.dart';

/// Cloudflare Worker API client (frozen contract v1).
///
/// OFFLINE-FIRST (TRD §59 / PRD §50): every network failure degrades
/// gracefully. Enforcement events queue locally and flush later; config
/// fetch failures fall back to the last native-cached config. The app NEVER
/// requires this client for Study/Detox/Cage/Alarm/coins to work.
class ApiClient {
  ApiClient._();

  static final ApiClient instance = ApiClient._();

  String? _accessToken;
  String? _refreshToken;
  String? _deviceId;

  String? get deviceId => _deviceId;
  bool get isAuthenticated => _accessToken != null;

  // v2.5.5 audit fix: last fetched server feature flags (GET /flags ->
  // {flags: {key: bool}}). Held CLIENT-SIDE only — they are deliberately NOT
  // pushed through NativeBridge.applyRemoteConfig because Kotlin's
  // RuntimeConfig has no flags surface and would treat a {'flags': ...}
  // payload as an all-defaults config, wiping the cached remote values.
  Map<String, bool> featureFlags = {};

  // ---------------------------------------------------------------------
  // Auth (Google Sign-In credential -> Worker session)
  // ---------------------------------------------------------------------

  Future<bool> loginWithGoogle(String idToken) async {
    final res = await _post('/auth/google', {'credential': idToken}, authenticated: false);
    if (res == null) return false;
    final tokens = res['tokens'] as Map<dynamic, dynamic>?;
    if (tokens == null) return false;
    _accessToken = tokens['accessToken'] as String?;
    _refreshToken = tokens['refreshToken'] as String?;
    await _persistSession();
    return _accessToken != null;
  }

  Future<void> logout() async {
    if (_accessToken != null) {
      await _post('/auth/logout', null);
    }
    _accessToken = null;
    _refreshToken = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('mld_auth');
  }

  Future<void> restoreSession() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('mld_auth');
    if (raw == null) return;
    try {
      final map = jsonDecode(raw) as Map<String, dynamic>;
      _accessToken = map['access'] as String?;
      _refreshToken = map['refresh'] as String?;
      _deviceId = map['deviceId'] as String?;
    } catch (_) {
      await prefs.remove('mld_auth');
    }
  }

  Future<void> _persistSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('mld_auth', jsonEncode({
      'access': _accessToken,
      'refresh': _refreshToken,
      'deviceId': _deviceId,
    }));
  }

  Future<bool> _tryRefresh() async {
    if (_refreshToken == null) return false;
    final res = await _post('/auth/refresh', {'refreshToken': _refreshToken}, authenticated: false);
    if (res == null) return false;
    final tokens = res['tokens'] as Map<dynamic, dynamic>?;
    if (tokens == null) return false;
    _accessToken = tokens['accessToken'] as String?;
    _refreshToken = tokens['refreshToken'] as String?;
    await _persistSession();
    return _accessToken != null;
  }

  // ---------------------------------------------------------------------
  // Device
  // ---------------------------------------------------------------------

  Future<void> ensureDeviceRegistered() async {
    if (!isAuthenticated || _deviceId != null) return;
    final res = await _post('/devices/register', {
      'model': 'android',
      'manufacturer': 'unknown',
      'androidVersion': 'unknown',
      'appVersion': AppConstants.appVersion,
    });
    if (res != null) {
      _deviceId = res['deviceId'] as String?;
      await _persistSession();
    }
  }

  Future<void> sendHeartbeat({
    required Map<String, bool> permissionSummary,
    required bool activeSession,
  }) async {
    if (!isAuthenticated) return;
    await _post('/devices/heartbeat', {
      'appVersion': AppConstants.appVersion,
      'permissionSummary': permissionSummary,
      'activeSession': activeSession,
    });
  }

  // ---------------------------------------------------------------------
  // Config / flags / announcements / version
  // ---------------------------------------------------------------------

  Future<Map<String, dynamic>?> fetchConfig() => _get('/config');

  Future<Map<String, dynamic>?> fetchFlags() => _get('/flags');

  // v2.5.5 audit fix: /app/version is a PUBLIC worker route (no
  // requireUser — "force-update must work pre-login", routes/app.ts), so
  // fetch it unauthenticated or the update nudge would be skipped for
  // signed-out users (the default-authenticated GET returns null without
  // an access token).
  Future<Map<String, dynamic>?> fetchAppVersion() =>
      _get('/app/version', authenticated: false);

  /// Active announcements (pull model — no push dependency by design).
  Future<List<Map<dynamic, dynamic>>> fetchAnnouncements(
      {String? since}) async {
    // v2.5.5 audit fix: `since` is an ISO timestamp — a `+` in it would be
    // read as a space without query-component encoding.
    final res = await _get(
      since == null
          ? '/announcements'
          : '/announcements?since=${Uri.encodeQueryComponent(since)}',
    );
    if (res == null) return const [];
    final list = res['announcements'] as List<dynamic>? ?? const [];
    return list.map((e) => Map<dynamic, dynamic>.from(e as Map)).toList();
  }

  // ---------------------------------------------------------------------
  // v2.2 Phase D — plans / trial / subscription / bKash gateway
  // ---------------------------------------------------------------------

  Future<List<Map<dynamic, dynamic>>> fetchPlans() async {
    final res = await _get('/plans');
    if (res == null) return const [];
    final list = res['plans'] as List<dynamic>? ?? const [];
    return list.map((e) => Map<dynamic, dynamic>.from(e as Map)).toList();
  }

  Future<Map<dynamic, dynamic>?> fetchTrial() => _get('/trial');

  Future<Map<dynamic, dynamic>?> claimTrial() =>
      _post('/trial/claim', {'confirm': true});

  Future<Map<dynamic, dynamic>?> fetchSubscription() => _get('/subscription');

  /// Forward a completed Play purchase for server verification. The Worker
  /// re-checks the token with the Play Developer API before granting PRO —
  /// this client is never the entitlement authority.
  Future<bool> verifyPlayPurchase({
    required String productId,
    required String purchaseToken,
  }) async {
    final res = await _post('/subscription/verify', {
      'productId': productId,
      'purchaseToken': purchaseToken,
      'platform': 'android',
    });
    return res != null;
  }

  Future<Map<dynamic, dynamic>?> fetchBkashInstructions() =>
      _get('/payments/bkash/instructions');

  Future<Map<dynamic, dynamic>?> bkashInit(String planId) =>
      _post('/payments/bkash/init', {'planId': planId});

  Future<Map<dynamic, dynamic>?> bkashSubmit(
      String paymentId, String trxId, String? senderNumber) {
    return _post('/payments/bkash/submit', {
      'paymentId': paymentId,
      'trxId': trxId,
      if (senderNumber != null && senderNumber.isNotEmpty)
        'senderNumber': senderNumber,
    });
  }

  Future<Map<dynamic, dynamic>?> bkashCancel(String paymentId) =>
      _post('/payments/bkash/cancel', {'paymentId': paymentId});

  Future<List<Map<dynamic, dynamic>>> fetchBkashStatus() async {
    final res = await _get('/payments/bkash/status');
    if (res == null) return const [];
    final list = res['payments'] as List<dynamic>? ?? const [];
    return list.map((e) => Map<dynamic, dynamic>.from(e as Map)).toList();
  }

  // ---------------------------------------------------------------------
  // v2.5 r9 — Social Sentry parity: AI companion / community / referral
  // ---------------------------------------------------------------------

  /// Sinthia chat via the Worker LLM proxy (dual-layer: server LLM when
  /// configured, scripted persona fallback otherwise).
  Future<Map<String, dynamic>?> chatWithCompanion({
    required String message,
    required Map<String, dynamic> context,
    required List<Map<String, dynamic>> history,
    int turn = 0,
  }) {
    final recent = history.length > 12
        ? history.sublist(history.length - 12)
        : history;
    return _post('/ai/chat', {
      'message': message,
      'context': context,
      'history': recent
          .map((m) => {'role': m['role'], 'content': m['content']})
          .toList(),
      'turn': turn,
    });
  }

  Future<List<Map<dynamic, dynamic>>> fetchCommunityFeed(
      {String filter = 'active'}) async {
    final res = await _get('/community/commits?filter=$filter');
    if (res == null) return const [];
    final list = res['commits'] as List<dynamic>? ?? const [];
    return list.map((e) => Map<dynamic, dynamic>.from(e as Map)).toList();
  }

  Future<Map<String, dynamic>?> createCommunityCommit({
    required int durationDays,
    required String reason,
    bool anonymous = false,
  }) {
    return _post('/community/commits', {
      'durationDays': durationDays,
      'reason': reason,
      'anonymous': anonymous,
    });
  }

  Future<Map<String, dynamic>?> cheerCommunityCommit(String commitId) =>
      _post('/community/commits/$commitId/cheer', null);

  Future<List<Map<dynamic, dynamic>>> searchUsers(String query) async {
    final res = await _get('/friends/search?q=${Uri.encodeQueryComponent(query)}');
    if (res == null) return const [];
    final list = res['users'] as List<dynamic>? ?? const [];
    return list.map((e) => Map<dynamic, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<dynamic, dynamic>>> fetchFriends() async {
    final res = await _get('/friends');
    if (res == null) return const [];
    final list = res['friends'] as List<dynamic>? ?? const [];
    return list.map((e) => Map<dynamic, dynamic>.from(e as Map)).toList();
  }

  Future<Map<String, dynamic>?> sendFriendRequest(String userId) =>
      _post('/friends/requests/$userId', null);

  Future<Map<String, dynamic>?> acceptFriendRequest(String userId) =>
      _post('/friends/requests/$userId/accept', null);

  Future<Map<String, dynamic>?> removeFriend(String userId) =>
      _post('/friends/$userId/remove', null);

  Future<Map<String, dynamic>?> fetchReferral() => _get('/referral');

  Future<Map<String, dynamic>?> claimReferralReward(String referralId) =>
      _post('/referral/claim', {'referralId': referralId});

  // ---------------------------------------------------------------------
  // Offline-safe event queue (PRD §41 / Backend §90)
  // ---------------------------------------------------------------------

  static const int _maxQueue = 500;

  Future<void> enqueueEvent(String type, Map<String, dynamic> payload) async {
    final prefs = await SharedPreferences.getInstance();
    final queue = await _loadQueue(prefs);
    queue.add({
      'eventId': 'evt_${_randomHex(16)}',
      'type': type,
      'payload': payload,
      'occurredAt': DateTime.now().toUtc().toIso8601String(),
    });
    // Bound the queue: oldest events drop first. Analytics must never
    // exhaust storage if the device stays offline for a long time.
    while (queue.length > _maxQueue) {
      queue.removeAt(0);
    }
    await prefs.setString('mld_event_queue', jsonEncode(queue));
  }

  Future<void> flushEventQueue() async {
    if (!isAuthenticated) return;
    final prefs = await SharedPreferences.getInstance();
    final queue = await _loadQueue(prefs);
    if (queue.isEmpty) return;

    // v2.5.5 audit fix: on a mid-flush failure the already-sent prefix is
    // dropped BEFORE returning — the old code re-uploaded it on the next
    // flush, duplicating every successfully-sent batch on flaky links.
    for (int i = 0; i < queue.length; i += 50) {
      final batch = queue.skip(i).take(50).toList();
      final ok = await _post('/events', {'events': batch});
      if (ok == null) {
        // Still offline — keep the FAILED batch and everything after it
        // (batches before i were uploaded and are dropped; batch i itself
        // failed and must be retried, not discarded).
        await prefs.setString(
            'mld_event_queue', jsonEncode(queue.skip(i).toList()));
        return;
      }
    }
    await prefs.setString('mld_event_queue', '[]');
  }

  Future<List<Map<String, dynamic>>> _loadQueue(SharedPreferences prefs) async {
    final raw = prefs.getString('mld_event_queue');
    if (raw == null) return [];
    try {
      return (jsonDecode(raw) as List<dynamic>)
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
    } catch (_) {
      return [];
    }
  }

  // ---------------------------------------------------------------------
  // Low-level (envelope unwrapping, refresh on 401)
  // ---------------------------------------------------------------------

  Future<Map<String, dynamic>?> _get(String path,
      {bool authenticated = true, int retry = 0}) {
    return _send('GET', path, null, authenticated, retry);
  }

  Future<Map<String, dynamic>?> _post(String path, Map<String, dynamic>? body,
      {bool authenticated = true, int retry = 0}) {
    return _send('POST', path, body, authenticated, retry);
  }

  Future<Map<String, dynamic>?> _send(
    String method,
    String path,
    Map<String, dynamic>? body,
    bool authenticated,
    int retry,
  ) async {
    if (authenticated && _accessToken == null) return null;
    try {
      final uri = Uri.parse('${AppConstants.apiBaseUrl}$path');
      final request = http.Request(method, uri);
      request.headers['Content-Type'] = 'application/json';
      if (authenticated) request.headers['Authorization'] = 'Bearer $_accessToken';
      if (body != null) request.body = jsonEncode(body);

      final response = await request.send().timeout(const Duration(seconds: 12));
      final text = await response.stream.bytesToString();
      if (text.isEmpty) return null;
      final Map<String, dynamic> envelope;
      try {
        envelope = jsonDecode(text) as Map<String, dynamic>;
      } catch (_) {
        return null;
      }
      if (envelope['success'] != true) {
        final error = envelope['error'] as Map<String, dynamic>?;
        final code = error?['code'] as String? ?? '';
        if (code == 'UNAUTHORIZED' && authenticated && retry == 0) {
          if (await _tryRefresh()) {
            return _send(method, path, body, authenticated, 1);
          }
        }
        return null;
      }
      final data = envelope['data'];
      if (data == null) return null;
      return Map<String, dynamic>.from(data as Map);
    } catch (_) {
      return null; // offline / timeout — fail safe, fail silent
    }
  }
}

String _randomHex(int bytes) {
  final rnd = Random.secure();
  return List.generate(bytes, (_) => rnd.nextInt(256).toRadixString(16).padLeft(2, '0')).join();
}
