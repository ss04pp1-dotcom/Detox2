import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/theme/tokens.dart';
import '../../data/api_client.dart';
import '../../shared/mld_widgets.dart';

/// CommunityScreen (v2.5 r9) — SS accountability-graph port: public
/// commitment feed (cheerable), friends (search/add/remove), referral
/// (code + share + rewards). Requires sign-in; guest state is explained.
class CommunityScreen extends StatefulWidget {
  const CommunityScreen({super.key});

  @override
  State<CommunityScreen> createState() => _CommunityScreenState();
}

class _CommunityScreenState extends State<CommunityScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs = TabController(length: 3, vsync: this);

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final signedIn = ApiClient.instance.isAuthenticated;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Community'),
        bottom: TabBar(
          controller: _tabs,
          tabs: const [
            Tab(text: 'Commits'),
            Tab(text: 'Friends'),
            Tab(text: 'Referral'),
          ],
        ),
      ),
      body: SafeArea(
        child: !signedIn
            ? const _SignInWall()
            : TabBarView(
                controller: _tabs,
                children: [
                  _CommitsTab(),
                  _FriendsTab(),
                  _ReferralTab(),
                ],
              ),
      ),
    );
  }
}

class _SignInWall extends StatelessWidget {
  const _SignInWall();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: AppSpacing.screenH,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.group_outlined,
                size: 48, color: AppColors.textDisabled),
            const SizedBox(height: AppSpacing.lg),
            const Text(
              'Community needs an account',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
            ),
            const SizedBox(height: AppSpacing.sm),
            const Text(
              'Sign in with Google (Settings → Account) to make public '
              'commitments, add friends and earn referral PRO days.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
            ),
            const SizedBox(height: AppSpacing.xl),
            MLDButton(
              label: 'Go to Settings',
              expanded: false,
              onPressed: () => Navigator.of(context).pushNamed('/settings'),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------
// Commits feed
// ---------------------------------------------------------------------

class _CommitsTab extends StatefulWidget {
  @override
  State<_CommitsTab> createState() => _CommitsTabState();
}

class _CommitsTabState extends State<_CommitsTab> {
  bool _loading = true;
  bool _busy = false;
  List<Map<dynamic, dynamic>> _commits = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final feed = await ApiClient.instance.fetchCommunityFeed();
    if (!mounted) return;
    setState(() {
      _commits = feed;
      _loading = false;
    });
  }

  Future<void> _create() async {
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      builder: (context) => const _NewCommitSheet(),
    );
    // v2.5.5 audit fix: mounted guard between the sheet await and setState.
    if (!mounted || result == null) return;
    setState(() => _busy = true);
    final ok = await ApiClient.instance.createCommunityCommit(
      durationDays: result['days'] as int,
      reason: result['reason'] as String,
      anonymous: result['anonymous'] as bool? ?? false,
    );
    if (!mounted) return;
    setState(() => _busy = false);
    if (ok == null) {
      _toast('Could not post — you look offline.');
    } else {
      _toast('Commitment posted. Do not let them watch you fold.');
      _load();
    }
  }

  Future<void> _cheer(Map<dynamic, dynamic> commit) async {
    await ApiClient.instance
        .cheerCommunityCommit(commit['id'].toString());
    _load();
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        RefreshIndicator(
          onRefresh: _load,
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _commits.isEmpty
                  ? ListView(
                      children: const [
                        SizedBox(height: 120),
                        Center(
                          child: Text('No active commitments yet.\nBe the first to go public.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: AppColors.textSecondary)),
                        ),
                      ],
                    )
                  : ListView.builder(
                      padding: AppSpacing.screenH
                          .copyWith(bottom: AppSpacing.xxxl),
                      itemCount: _commits.length,
                      itemBuilder: (context, i) {
                        final c = _commits[i];
                        final mine = c['mine'] == true;
                        final cheered = c['hasCheered'] == true;
                        return Padding(
                          padding: const EdgeInsets.only(bottom: AppSpacing.md),
                          child: MLDCard(
                            padding: const EdgeInsets.all(AppSpacing.lg),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      mine ? Icons.person : Icons.public,
                                      size: 16,
                                      color: AppColors.textSecondary,
                                    ),
                                    const SizedBox(width: AppSpacing.sm),
                                    Expanded(
                                      child: Text(
                                        mine
                                            ? 'You'
                                            : (c['displayName'] as String? ??
                                                'Anonymous'),
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w600,
                                            fontSize: 13),
                                      ),
                                    ),
                                    Text(
                                      '${c['durationDays']} days',
                                      style: const TextStyle(
                                          fontSize: 12,
                                          color: AppColors.primary),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: AppSpacing.sm),
                                Text(
                                  c['reason']?.toString() ?? '',
                                  style: const TextStyle(fontSize: 14),
                                ),
                                const SizedBox(height: AppSpacing.md),
                                Row(
                                  children: [
                                    Icon(Icons.local_fire_department,
                                        size: 16,
                                        color: cheered
                                            ? AppColors.warning
                                            : AppColors.textDisabled),
                                    const SizedBox(width: AppSpacing.xs),
                                    Text('${c['cheersCount'] ?? 0} cheers'),
                                    const Spacer(),
                                    TextButton.icon(
                                      onPressed:
                                          cheered ? null : () => _cheer(c),
                                      icon: const Icon(Icons.thumb_up_outlined,
                                          size: 16),
                                      label: const Text('Cheer'),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
        ),
        if (_busy) const LinearProgressIndicator(minHeight: 2),
      ],
    );
  }
}

class _NewCommitSheet extends StatefulWidget {
  const _NewCommitSheet();

  @override
  State<_NewCommitSheet> createState() => _NewCommitSheetState();
}

class _NewCommitSheetState extends State<_NewCommitSheet> {
  int _days = 7;
  bool _anonymous = false;
  final _reason = TextEditingController();

  // v2.5.5 audit fix: the sheet's TextEditingController was never disposed.
  @override
  void dispose() {
    _reason.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: AppSpacing.xl,
        right: AppSpacing.xl,
        top: AppSpacing.xl,
        bottom: MediaQuery.of(context).viewInsets.bottom + AppSpacing.xl,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const MLDSectionHeader(title: 'Public commitment'),
          const SizedBox(height: AppSpacing.md),
          TextField(
            controller: _reason,
            maxLines: 2,
            decoration: const InputDecoration(
              hintText: 'What are you committing to? (public)',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: AppSpacing.md),
          Wrap(
            spacing: AppSpacing.md,
            children: [3, 7, 14, 30]
                .map((d) => ChoiceChip(
                      label: Text('$d days'),
                      selected: _days == d,
                      onSelected: (_) => setState(() => _days = d),
                    ))
                .toList(),
          ),
          SwitchListTile(
            value: _anonymous,
            onChanged: (v) => setState(() => _anonymous = v),
            title: const Text('Post anonymously', style: TextStyle(fontSize: 14)),
            contentPadding: EdgeInsets.zero,
            dense: true,
          ),
          MLDButton(
            label: 'Commit publicly',
            onPressed: () => Navigator.of(context).pop({
              'days': _days,
              'reason': _reason.text.trim(),
              'anonymous': _anonymous,
            }),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------
// Friends
// ---------------------------------------------------------------------

class _FriendsTab extends StatefulWidget {
  @override
  State<_FriendsTab> createState() => _FriendsTabState();
}

class _FriendsTabState extends State<_FriendsTab> {
  bool _loading = true;
  List<Map<dynamic, dynamic>> _friends = const [];
  final _query = TextEditingController();
  List<Map<dynamic, dynamic>> _results = const [];
  bool _searching = false;

  // v2.5.5 audit fix: the search field's TextEditingController was never
  // disposed.
  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final friends = await ApiClient.instance.fetchFriends();
    if (!mounted) return;
    setState(() {
      _friends = friends;
      _loading = false;
    });
  }

  Future<void> _search() async {
    final q = _query.text.trim();
    if (q.length < 2) return;
    setState(() => _searching = true);
    final results = await ApiClient.instance.searchUsers(q);
    if (!mounted) return;
    setState(() {
      _results = results;
      _searching = false;
    });
  }

  Future<void> _add(String userId) async {
    final res = await ApiClient.instance.sendFriendRequest(userId);
    if (!mounted) return;
    _toast(res != null && res['ok'] == true
        ? 'Request sent'
        : (res?['message'] as String? ?? 'Could not send'));
  }

  /// v2.5.5 audit fix: `[0]` on an EMPTY display name threw RangeError —
  /// derive the avatar initial defensively (shared by search results and
  /// the friends list).
  String _initial(dynamic name) {
    final s = (name as String?)?.trim() ?? '';
    return s.isEmpty ? '?' : s[0];
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return _loading
        ? const Center(child: CircularProgressIndicator())
        : ListView(
            padding: AppSpacing.screenH.copyWith(bottom: AppSpacing.xxxl),
            children: [
              TextField(
                controller: _query,
                onSubmitted: (_) => _search(),
                decoration: InputDecoration(
                  hintText: 'Search users…',
                  prefixIcon: const Icon(Icons.search),
                  border: const OutlineInputBorder(),
                  isDense: true,
                  suffixIcon: _searching
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: Padding(
                            padding: EdgeInsets.all(6),
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        )
                      : IconButton(
                          icon: const Icon(Icons.arrow_forward),
                          onPressed: _search,
                        ),
                ),
              ),
              if (_results.isNotEmpty) ...[
                const SizedBox(height: AppSpacing.md),
                ..._results.map((u) => ListTile(
                      leading: CircleAvatar(
                        backgroundColor: AppColors.elevated,
                        child: Text(_initial(u['displayName'])),
                      ),
                      title: Text(u['displayName']?.toString() ?? '?',
                          style: const TextStyle(fontSize: 14)),
                      subtitle: u['rank'] != null
                          ? Text(u['rank'].toString(),
                              style: const TextStyle(fontSize: 11))
                          : null,
                      trailing: TextButton(
                        onPressed: () => _add(u['id'].toString()),
                        child: const Text('Add'),
                      ),
                      dense: true,
                    )),
                const SizedBox(height: AppSpacing.xl),
              ],
              MLDSectionHeader(title: 'Friends (${_friends.length})'),
              const SizedBox(height: AppSpacing.md),
              ..._friends.map((f) => ListTile(
                    leading: CircleAvatar(
                      backgroundColor: AppColors.elevated,
                      child: Text(_initial(f['displayName'])),
                    ),
                    title: Text(f['displayName']?.toString() ?? '?',
                        style: const TextStyle(fontSize: 14)),
                    subtitle: Text(
                        'Streak ${f['streakDays'] ?? 0} days',
                        style: const TextStyle(fontSize: 11)),
                    dense: true,
                  )),
            ],
          );
  }
}

// ---------------------------------------------------------------------
// Referral
// ---------------------------------------------------------------------

class _ReferralTab extends StatefulWidget {
  @override
  State<_ReferralTab> createState() => _ReferralTabState();
}

class _ReferralTabState extends State<_ReferralTab> {
  bool _loading = true;
  Map<String, dynamic>? _data;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await ApiClient.instance.fetchReferral();
    if (!mounted) return;
    setState(() {
      _data = data;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final code = _data?['code'] as String? ?? '';
    final proDays = _data?['proDaysEarned'] as int? ?? 0;
    final qualified = _data?['qualifiedReferrals'] as int? ?? 0;
    final pending = _data?['pendingRewards'] as List<dynamic>? ?? const [];

    return _loading
        ? const Center(child: CircularProgressIndicator())
        : ListView(
            padding: AppSpacing.screenH.copyWith(bottom: AppSpacing.xxxl),
            children: [
              MLDCard(
                child: Column(
                  children: [
                    const MLDSectionHeader(title: 'Your referral code'),
                    const SizedBox(height: AppSpacing.md),
                    Text(
                      code.isEmpty ? '—' : code,
                      style: const TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 3),
                    ),
                    const SizedBox(height: AppSpacing.md),
                    MLDButton(
                      label: 'Share invite link',
                      expanded: false,
                      onPressed: code.isEmpty
                          ? null
                          : () async {
                              // v2.5.5 audit fix: the button body used to be
                              // EMPTY — it did nothing. Clipboard fallback
                              // (no share-sheet dependency by design).
                              await Clipboard.setData(ClipboardData(
                                  text: 'https://maxleveldetox.com/r/$code'));
                              if (!mounted) return;
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text('Invite link copied')),
                              );
                            },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.xl),
              MLDCard(
                child: Column(
                  children: [
                    _stat('Qualified referrals', '$qualified'),
                    _stat('PRO days earned', '$proDays'),
                    _stat('Milestones',
                        '3→+1d · 5→+3d · 10→+7d · 20→+15d · 50→+30d'),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.xl),
              if (pending.isNotEmpty) ...[
                MLDSectionHeader(
                    title: 'Pending rewards (${pending.length})'),
                const SizedBox(height: AppSpacing.md),
                ...pending.map((p) => ListTile(
                      leading: const Icon(Icons.card_giftcard),
                      title: Text('Claimable reward',
                          style: const TextStyle(fontSize: 14)),
                      trailing: TextButton(
                        onPressed: () async {
                          await ApiClient.instance.claimReferralReward(
              (p as Map)['id'].toString());
                          _load();
                        },
                        child: const Text('Claim'),
                      ),
                      dense: true,
                    )),
              ],
              const Text(
                'Friend signs in with Google and claims within 7 days → they '
                'get 1 day PRO instantly, you get 1 day PRO per qualified '
                'referral (milestones stack, 180 free days/year cap). '
                'Anti-fraud: no self, fake, bot or circular referrals.',
                style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
              ),
            ],
          );
  }

  Widget _stat(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: AppSpacing.sm),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(fontSize: 13)),
            Text(value,
                style: const TextStyle(
                    fontWeight: FontWeight.w700, fontSize: 13)),
          ],
        ),
      );
}
