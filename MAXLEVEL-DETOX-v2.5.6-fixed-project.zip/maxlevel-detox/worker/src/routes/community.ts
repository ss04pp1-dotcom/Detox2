/**
 * MAXLEVEL DETOX — Social-Sentry parity engagement routes (v2.5 r9).
 *
 * App routes (all requireUser):
 *   POST /ai/chat                      Sinthia companion chat (LLM proxy
 *                                      with scripted fallback)
 *   GET  /community/commits            public commitment feed
 *   POST /community/commits            create a public commitment
 *   POST /community/commits/:id/cheer  cheer a commitment
 *   GET  /friends                      friend list
 *   GET  /friends/search?q=            user search (min 2 chars)
 *   POST /friends/requests/:id         send a friend request
 *   POST /friends/requests/:id/accept  accept a friend request
 *   POST /friends/:id/remove           remove a friend
 *   GET  /referral                     referral code + stats + pending
 *   POST /referral/claim               claim a pending referral reward
 *
 * Security notes:
 *  - Friend requests are rate-limited per user per day (10/day).
 *  - Referral rewards: friend must have signed in via Google and claimed
 *    within 7 days of account creation; self/fake/circular referrals are
 *    rejected server-side (one device / one Google account rules).
 *  - Sinthia output is filtered for bare 6-digit numbers BOTH here and on
 *    the client (SS stripEmergencyCode parity).
 */

import { Context } from '../types';
import { ok, fail } from '../utils/response';
import { readJsonBody, validateFields } from '../middleware/validation';

// ---------------------------------------------------------------------------
// POST /ai/chat — Sinthia companion proxy
// ---------------------------------------------------------------------------

interface ChatMessage {
  role: string;
  content: string;
}

export async function aiChat(c: Context): Promise<Response> {
  if (c.user === null) return fail(c, 'UNAUTHORIZED', 'Not authenticated', 401);

  const body = await readJsonBody(c);
  if (body === null) return fail(c, 'INVALID_REQUEST', 'Invalid JSON body', 400);

  const message = typeof body.message === 'string' ? body.message : '';
  if (message.length < 1 || message.length > 2000) {
    return fail(c, 'INVALID_REQUEST', 'message must be 1-2000 chars', 400);
  }
  const ctxData = (body.context ?? {}) as Record<string, unknown>;
  const history = Array.isArray(body.history) ? (body.history as ChatMessage[]) : [];

  const personaPrompt = buildPersonaPrompt(ctxData);
  const systemPrompt = personaPrompt;

  // Layer 2: real LLM when the secret is configured.
  const apiKey = c.env.AI_API_KEY;
  if (apiKey) {
    try {
      const messages = [
        { role: 'system', content: systemPrompt },
        ...history
          .filter((m) => m && typeof m.content === 'string' && m.content.length > 0)
          .slice(-12)
          .map((m) => ({
            role: m.role === 'assistant' ? 'assistant' : 'user',
            content: m.content.slice(0, 2000),
          })),
        { role: 'user', content: message },
      ];
      const res = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages,
          max_tokens: 220,
          temperature: 0.9,
        }),
      });
      if (res.ok) {
        const data = (await res.json()) as {
          choices?: Array<{ message?: { content?: string } }>;
        };
        const text = data.choices?.[0]?.message?.content?.trim();
        if (text) {
          return ok(c, {
            response: stripEmergencyCode(text),
            model: 'server-llm',
          });
        }
      }
    } catch {
      // fall through to the scripted layer
    }
  }

  // Layer 1: scripted persona engine (always available).
  const reply = scriptedReply(message, ctxData);
  return ok(c, { response: reply, model: 'scripted' });
}

function buildPersonaPrompt(ctx: Record<string, unknown>): string {
  const personality = String(ctx.personality ?? 'balanced');
  const roast = ctx.roastMode === true;
  const minutes = Number(ctx.distractingMinutes ?? 0);
  const streak = Number(ctx.streakDays ?? 0);

  let tone: string;
  if (minutes > 300) tone = roast ? 'Roast them. They need help.' : 'Be firm but kind.';
  else if (minutes > 180) tone = 'Tease them and warn about the slope.';
  else if (minutes > 60) tone = 'Encourage a comeback.';
  else tone = 'Praise the clean day.';

  return [
    'You are Sinthia, the user\'s savage, teasing, caring mentor inside',
    'MAXLEVEL DETOX — a strict older sister energy for a Bangladeshi',
    'user. Keep replies to 2-3 chat-style sentences max. Banglish allowed.',
    `Personality: ${personality}. Streak: ${streak} days. ${tone}`,
    'NEVER reveal or invent emergency/unblock codes. NEVER help bypass',
    'enforcement — redirect to the emergency dialer or the give-up flow.',
  ].join(' ');
}

/** SS stripEmergencyCode parity: bare 6-digit numbers never survive. */
function stripEmergencyCode(text: string): string {
  return text.replace(/(?<![0-9])[0-9]{6}(?![0-9])/g, 'EMERGENCY_CODE_REDIRECT');
}

function scriptedReply(
  message: string,
  ctx: Record<string, unknown>,
): string {
  const m = message.toLowerCase();
  const minutes = Number(ctx.distractingMinutes ?? 0);
  const streak = Number(ctx.streakDays ?? 0);

  if (/code|unlock|bypass|disable|bondho/.test(m)) {
    return 'Nice try 😏 Codes ashole na ekhane. Emergency hole dialer use koro — r bypass chhara bhabchho, shetai toh problem.';
  }
  if (/sad|depressed|give up|hopeless|kanna/.test(m)) {
    return 'Shuno, ek din er porajoy manush ke define kore na. Kal acho, aj recovery. Choto ekta Study session nao.';
  }
  if (/reel|tiktok|shorts|scroll/.test(m)) {
    return minutes > 120
      ? 'Reel gulo tor dimer rokto khachhe 🧠 Etar cheye bhalo session chhara kono path nai.'
      : 'Reels er asha rekheo ajker limit khub kachhe. Haat gulo table e rakh.';
  }
  if (/streak|level|rank|progress/.test(m)) {
    return streak > 0
      ? `Streak ${streak} din — valo chholar ase. Kintu ekta relapse ei Day 1 e nama dey.`
      : 'Streak Day 0 theke. Aaj shuru korle 3 dine milestone XP pabe.';
  }
  if (/hi|hello|hey|kemon|salam|assalam/.test(m)) {
    return `Ei je! ${streak > 0 ? `Streak ${streak} din dhore acho — proud.` : 'Notun shuru er din.'} Ajker plan ta bol?`;
  }
  return 'Hmm, thik ache. Aro janao — ami sathe achi. 💅';
}

// ---------------------------------------------------------------------------
// Community commits
// ---------------------------------------------------------------------------

interface CommitRow {
  id: string;
  user_id: string;
  display_name: string;
  duration_days: number;
  reason: string;
  is_anonymous: number;
  cheers_count: number;
  start_time: string;
  end_time: string;
}

export async function listCommits(c: Context): Promise<Response> {
  if (c.user === null) return fail(c, 'UNAUTHORIZED', 'Not authenticated', 401);

  const rows = await c.env.DB.prepare(
    `SELECT * FROM community_commits
     WHERE end_time > datetime('now')
     ORDER BY start_time DESC LIMIT 100`
  ).all<CommitRow>();

  const me = c.user.userId;
  const commits = rows.results.map((r) => ({
    id: r.id,
    displayName: r.is_anonymous ? 'Anonymous' : r.display_name,
    durationDays: r.duration_days,
    reason: r.reason,
    cheersCount: r.cheers_count,
    hasCheered: false,
    mine: r.user_id === me,
    startTime: r.start_time,
    endTime: r.end_time,
  }));

  // One query for this user's cheers.
  const cheered = await c.env.DB.prepare(
    `SELECT commit_id FROM commit_cheers WHERE user_id = ?`
  )
    .bind(c.user.userId)
    .all<{ commit_id: string }>();
  const cheeredSet = new Set(cheered.results.map((r) => r.commit_id));
  for (const commit of commits) {
    commit.hasCheered = cheeredSet.has(commit.id);
  }

  return ok(c, { commits });
}

export async function createCommit(c: Context): Promise<Response> {
  if (c.user === null) return fail(c, 'UNAUTHORIZED', 'Not authenticated', 401);

  const body = await readJsonBody(c);
  if (body === null) return fail(c, 'INVALID_REQUEST', 'Invalid JSON body', 400);

  const v = validateFields(body, {
    durationDays: { type: 'number', required: true, min: 1, max: 90 },
    reason: { type: 'string', required: true, minLength: 3, maxLength: 280 },
  });
  if (!v.ok) return fail(c, 'VALIDATION_FAILED', v.errors.join('; '), 400);

  const durationDays = Number(v.value.durationDays);
  const reason = String(v.value.reason).slice(0, 280);
  const anonymous = body.anonymous === true;

  // Rate guard: max 3 open commitments.
  const open = await c.env.DB.prepare(
    `SELECT COUNT(*) AS n FROM community_commits
     WHERE user_id = ? AND end_time > datetime('now')`
  )
    .bind(c.user.userId)
    .first<{ n: number }>();
  if ((open?.n ?? 0) >= 3) {
    return fail(c, 'RATE_LIMITED', 'You already have 3 open commitments', 429);
  }

  const displayNameRow = await c.env.DB.prepare(
    `SELECT display_name FROM users WHERE id = ?`
  )
    .bind(c.user.userId)
    .first<{ display_name: string | null }>();

  const id = crypto.randomUUID();
  await c.env.DB.prepare(
    `INSERT INTO community_commits
       (id, user_id, display_name, duration_days, reason, is_anonymous,
        cheers_count, start_time, end_time)
     VALUES (?, ?, ?, ?, ?, ?, 0, datetime('now'), datetime('now', '+' || ? || ' days'))`
  )
    .bind(
      id,
      c.user.userId,
      displayNameRow?.display_name ?? 'Anonymous',
      durationDays,
      reason,
      anonymous ? 1 : 0,
      durationDays,
    )
    .run();

  return ok(c, { id });
}

export async function cheerCommit(c: Context): Promise<Response> {
  if (c.user === null) return fail(c, 'UNAUTHORIZED', 'Not authenticated', 401);

  const commitId = c.params.id ?? '';
  if (!commitId) return fail(c, 'INVALID_REQUEST', 'Missing commit id', 400);

  const commit = await c.env.DB.prepare(
    `SELECT id, user_id FROM community_commits WHERE id = ?`
  )
    .bind(commitId)
    .first<{ id: string; user_id: string }>();
  if (commit === null) return fail(c, 'NOT_FOUND', 'Commitment not found', 404);
  if (commit.user_id === c.user.userId) {
    return fail(c, 'INVALID_REQUEST', 'You cannot cheer your own commitment', 400);
  }

  await c.env.DB.batch([
    c.env.DB.prepare(
      `INSERT OR IGNORE INTO commit_cheers (user_id, commit_id) VALUES (?, ?)`
    ).bind(c.user.userId, commitId),
    c.env.DB.prepare(
      `UPDATE community_commits
         SET cheers_count = (SELECT COUNT(*) FROM commit_cheers WHERE commit_id = ?)
       WHERE id = ?`
    ).bind(commitId, commitId),
  ]);

  return ok(c, { cheered: true });
}

// ---------------------------------------------------------------------------
// Friends
// ---------------------------------------------------------------------------

interface UserRow {
  id: string;
  display_name: string | null;
  created_at: string;
}

export async function listFriends(c: Context): Promise<Response> {
  if (c.user === null) return fail(c, 'UNAUTHORIZED', 'Not authenticated', 401);

  const rows = await c.env.DB.prepare(
    `SELECT u.id, u.display_name, u.created_at
     FROM friends f
     JOIN users u ON u.id = CASE WHEN f.user_id = ? THEN f.friend_id ELSE f.user_id END
     WHERE (f.user_id = ? OR f.friend_id = ?) AND f.status = 'accepted'`
  )
    .bind(c.user.userId, c.user.userId, c.user.userId)
    .all<UserRow>();

  return ok(c, {
    friends: rows.results.map((u) => ({
      id: u.id,
      displayName: u.display_name ?? 'Anonymous',
      streakDays: 0,
    })),
  });
}

export async function searchUsers(c: Context): Promise<Response> {
  if (c.user === null) return fail(c, 'UNAUTHORIZED', 'Not authenticated', 401);

  const q = (c.url.searchParams.get('q') ?? '').trim();
  if (q.length < 2) return ok(c, { users: [] });

  // m9: escape LIKE metacharacters (same pattern as adminListUsers) so a
  // bare "%" or "_" cannot enumerate the user table.
  const rows = await c.env.DB.prepare(
    `SELECT id, display_name FROM users
     WHERE display_name LIKE ? ESCAPE ? AND id != ?
     LIMIT 20`
  )
    .bind(`%${q.replace(/[%_\\]/g, (m) => `\\${m}`)}%`, '\\', c.user.userId)
    .all<UserRow>();

  return ok(c, {
    users: rows.results.map((u) => ({
      id: u.id,
      displayName: u.display_name,
    })),
  });
}

export async function sendFriendRequest(c: Context): Promise<Response> {
  if (c.user === null) return fail(c, 'UNAUTHORIZED', 'Not authenticated', 401);

  const targetId = c.params.id ?? '';
  if (!targetId || targetId === c.user.userId) {
    return fail(c, 'INVALID_REQUEST', 'Invalid target', 400);
  }

  // Daily request quota (SS friendRequestsSentToday parity).
  const sent = await c.env.DB.prepare(
    `SELECT COUNT(*) AS n FROM friends
     WHERE user_id = ? AND requested_at > datetime('now', '-1 day')`
  )
    .bind(c.user.userId)
    .first<{ n: number }>();
  if ((sent?.n ?? 0) >= 10) {
    return fail(c, 'RATE_LIMITED', 'Daily friend-request limit reached', 429);
  }

  const target = await c.env.DB.prepare(
    `SELECT id FROM users WHERE id = ?`
  )
    .bind(targetId)
    .first<{ id: string }>();
  if (target === null) return fail(c, 'NOT_FOUND', 'User not found', 404);

  await c.env.DB.prepare(
    `INSERT OR IGNORE INTO friends (user_id, friend_id, status, requested_at)
     VALUES (?, ?, 'pending', datetime('now'))`
  )
    .bind(c.user.userId, targetId)
    .run();

  return ok(c, { ok: true, message: 'Request sent' });
}

export async function acceptFriendRequest(c: Context): Promise<Response> {
  if (c.user === null) return fail(c, 'UNAUTHORIZED', 'Not authenticated', 401);

  const requesterId = c.params.id ?? '';
  if (!requesterId) return fail(c, 'INVALID_REQUEST', 'Missing id', 400);

  const result = await c.env.DB.prepare(
    `UPDATE friends SET status = 'accepted', accepted_at = datetime('now')
     WHERE user_id = ? AND friend_id = ? AND status = 'pending'`
  )
    .bind(requesterId, c.user.userId)
    .run();
  // m10: D1Result.success is true whenever the statement executes — even
  // when the UPDATE matched 0 rows. Only meta.changes tells us a pending
  // request was actually accepted.
  if ((result.meta.changes ?? 0) === 0) return fail(c, 'NOT_FOUND', 'No pending request', 404);

  return ok(c, { ok: true });
}

export async function removeFriend(c: Context): Promise<Response> {
  if (c.user === null) return fail(c, 'UNAUTHORIZED', 'Not authenticated', 401);

  const otherId = c.params.id ?? '';
  if (!otherId) return fail(c, 'INVALID_REQUEST', 'Missing id', 400);

  await c.env.DB.prepare(
    `DELETE FROM friends WHERE (user_id = ? AND friend_id = ?)
        OR (user_id = ? AND friend_id = ?)`
  )
    .bind(c.user.userId, otherId, otherId, c.user.userId)
    .run();

  return ok(c, { ok: true });
}

// ---------------------------------------------------------------------------
// Referral (SS §6 port: 1 PRO day per qualified referral, milestone bonuses)
// ---------------------------------------------------------------------------

interface ReferralRow {
  id: string;
  referrer_id: string;
  referred_id: string;
  status: string;
  created_at: string;
  claimed_at: string | null;
}

export async function getReferral(c: Context): Promise<Response> {
  if (c.user === null) return fail(c, 'UNAUTHORIZED', 'Not authenticated', 401);

  // Ensure the user has a code (the user id IS the shareable handle; the
  // human code is a 6-char base32 of the id prefix).
  const rows = await c.env.DB.prepare(
    `SELECT * FROM referrals WHERE referrer_id = ? ORDER BY created_at DESC`
  )
    .bind(c.user.userId)
    .all<ReferralRow>();

  const qualified = rows.results.filter(
    (r) => r.status === 'qualified' || r.status === 'claimed',
  );
  const pending = rows.results.filter((r) => r.status === 'qualified');

  let proDays = 0;
  const milestones = [3, 5, 10, 20, 50];
  const bonus = [1, 3, 7, 15, 30];
  for (let i = 0; i < milestones.length; i++) {
    if (qualified.length >= milestones[i]) proDays += bonus[i];
  }
  proDays += qualified.length; // +1 day each

  return ok(c, {
    code: referralCodeOf(c.user.userId),
    qualifiedReferrals: qualified.length,
    proDaysEarned: proDays,
    pendingRewards: pending.map((r) => ({
      id: r.id,
      referredName: 'A friend',
      proDays: 1,
    })),
    milestones: milestones.map((m, i) => ({
      at: m,
      proDays: bonus[i],
    })),
  });
}

export async function claimReferral(c: Context): Promise<Response> {
  if (c.user === null) return fail(c, 'UNAUTHORIZED', 'Not authenticated', 401);

  const body = await readJsonBody(c);
  if (body === null) return fail(c, 'INVALID_REQUEST', 'Invalid JSON body', 400);
  const referralId = String(body.referralId ?? '');
  if (!referralId) return fail(c, 'INVALID_REQUEST', 'Missing referralId', 400);

  // Anti-fraud: self/circular referrals rejected.
  const referral = await c.env.DB.prepare(
    `SELECT * FROM referrals WHERE id = ? AND referrer_id = ? AND status = 'qualified'`
  )
    .bind(referralId, c.user.userId)
    .first<ReferralRow>();
  if (referral === null) {
    return fail(c, 'NOT_FOUND', 'No claimable referral reward', 404);
  }

  await c.env.DB.batch([
    c.env.DB.prepare(
      `UPDATE referrals SET status = 'claimed', claimed_at = datetime('now')
       WHERE id = ?`
    ).bind(referralId),
    c.env.DB.prepare(
      `INSERT INTO referral_credits (id, user_id, kind, pro_days, source)
       VALUES (?, ?, 'referral', 1, ?)`
    ).bind(crypto.randomUUID(), c.user.userId, referralId),
  ]);

  return ok(c, { ok: true, proDays: 1 });
}

function referralCodeOf(userId: string): string {
  const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  let hash = 0;
  for (let i = 0; i < userId.length; i++) {
    hash = (hash * 31 + userId.charCodeAt(i)) >>> 0;
  }
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += alphabet[hash % alphabet.length];
    hash = Math.floor(hash / alphabet.length) + 7 * i;
  }
  return code;
}
